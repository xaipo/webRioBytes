# Open Sans @font-face kit

Installable via [Bower](http://twitter.github.com/bower/):
```
bower install open-sans-fontface
```

## Demo
__Our repository:__ [http://fontfacekit.github.com/open-sans](http://fontfacekit.github.com/open-sans)

__Google Web Fonts:__ [http://www.google.com/fonts/specimen/Open+Sans](http://www.google.com/fonts/specimen/Open+Sans)
